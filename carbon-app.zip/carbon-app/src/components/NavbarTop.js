import React from 'react';

import "./SearchBar.css";

function NavbarTop () {
    return (

        <nav
        className="navbar navbar-expand-md navbar-light sticky-top"
        role="navigation"
      ></nav>
    );
}

export default NavbarTop;