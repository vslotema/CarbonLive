import React, { Component } from "react";
import { AiOutlineSearch } from "react-icons/ai";
import "./SearchBar.css";

class SearchBar extends Component {
  render() {
    return (
      <form className="form-inline my-2 my-lg-0">
        <input
          className="form-control mr-sm-2"
          type="search"
          placeholder="Search Country"
          aria-label="Search"
          onChange={(e) => this.props.onChange(e)}
        />

        <button
          type="button"
          onClick={() => this.props.onSubmit()}
          className="btn btn-light sm"
        >
          <AiOutlineSearch color="black" size="1.3rem"></AiOutlineSearch>
        </button>
      </form>
    );
  }
}

export default SearchBar;
