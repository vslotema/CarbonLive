export const MenuItems = [
  {
    title: "Carbon Live",
    url: "http://localhost:3000/CarbonLive",
    cName: "nav-links",
  },

  {
    title: "Energy Sources",
    url: "http://localhost:3000/EnergySources",
    cName: "nav-links",
  },

  {
    title: "Community",
    url: "#",
    cName: "nav-links",
  },

  {
    title: "Sign up",
    url: "#",
    cName: "nav-links-mobile",
  },
];
