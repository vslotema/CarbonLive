import React, { Component } from "react";
import "./App.css";
import CarbonLive from "./components/CarbonLive/CarbonLive";
import PowerBreakdown from "./components/PCB/PowerBreakdown";
import FetchData from "./components/FetchData";
import { BrowserRouter as Router, Switch, Route } from "react-router-dom";
import NavbarBottom from "./components/NavbarBottom";
import NavbarTop from "./components/NavbarTop";

class App extends Component {
  state = {
    carbonIntensity: [],
    breakdown: [],
  };

  handleCarbonData = (carbonIntensity) => {
    this.setState({ carbonIntensity });
    console.log("Carbon Intensity ", this.state.carbonIntensity);
  };

  handlePCBData = (breakdown) => {
    this.setState({ breakdown });
    console.log("Breakdown ", this.state.breakdown);
  };

  handleClickCarbonLive = () => {
    this.setState({ carbonlive: true });
  };

  render() {
    console.log("Current data carbon ", this.state.carbonIntensity);
    console.log("Current breakdown ", this.state.breakdown);
    return (
      <React.Fragment>
        <FetchData
          receiveCarbon={this.handleCarbonData}
          receivePCB={this.handlePCBData}
        ></FetchData>
        <NavbarTop />
        <Router>
          <NavbarBottom />
          <Switch>
            <Route
              exact
              path="/"
              render={(props) => (
                <CarbonLive {...props} isAuthed={this.state.carbonIntensity} />
              )}
            ></Route>

            <Route
              path="/powerbreakdown"
              render={(props) => (
                <PowerBreakdown {...props} isAuthed={this.state.breakdown} />
              )}
            />
          </Switch>
        </Router>
      </React.Fragment>
    );
  }
}

export default App;
